# Changelog

## [0.1.1] — 2026-11-03

- Fix: a new clip made while another take was shown (one that animates the armature object itself) also
  rewrote the model. Objects whose transform is animated are now fingerprinted and exported at the file's
  default transform, not at the current frame. Covered by a new self-test check (`new_clip_mid_take`).
- Blender opens straight into the model: no splash screen, the sidebar opens on the Unity tab.
- Textures the FBX points at but that are not there (pink in the viewport) are replaced by Unity's.
- Scrubbing or playing the timeline no longer raises "May have changes".
- Clip panel fits the default sidebar: Range shows the key range when no manual range is set, Motion, Simplify keys.
- Reports: one card per import with status, Select and History buttons; long lists fold. History and Reports
  can show one file. Reports say what was written ("Mesh updated", "Clips updated: …").
- Third-party files: when none of the configured content folders exists, only Assets/Plugins and Packages count.
- Tests leave no traces (cached .blend files, history, snapshots, manifests, reports of their copies);
  daily cleanup drops snapshots of deleted assets; `*.blend1` is ignored in ArtSource; no `__pycache__` in the package.
- Tooling: ArtSource/.bridge/automation.request drives the editor from outside (select, open, windows,
  window captures, scratch copies); Tests~/blender/docshots.py takes the documentation screenshots.
- README with a quick start, screenshots and diagrams.

## [0.1.0] — 2026-10-30

First version for testing on a real project.

- Open in Blender from the Project window, Hierarchy/scene and the inspector; picker when a prefab holds several models.
- Working .blend files in ArtSource/Cache (auto-cleanup) or ArtSource/Pinned (git LFS); GUID-based links.
- Smart export: content fingerprints decide which files to write; atomic replace; per-file history with rollback.
- FBX profile (axes, units, frame rate) of the source file is reproduced on export.
- Skinned models: mesh and skeleton edits, embedded takes kept with their names and timing.
- Clips: new clips as Model@Clip.fbx (bones only), editing clip FBX files, embedded takes and .anim assets.
- Unity side: clip settings (loop, root motion) for managed clips, take remapping, Humanoid avatar copy,
  material slots resolved by name or template, MeshColliders by suffix, before/after comparison report.
- Phase 0 test bench for headless Blender; end-to-end test through Unity on copies of real assets.
- Exact units (UnitScaleFactor 1 and 100 written exactly), source skin clusters kept, the file's default pose
  kept apart from takes, bone-attached objects placed where the file has them, clip files keep their own
  default pose, take names from files with named layers.
- Export stops on takes that animate objects it cannot write; mirrored end bones are reported.
- .anim: samples placed on the scene's frame grid; stepped clips (constant tangents) keep their key times and steps;
  only the channels Blender writes are replaced.
- Clip files keep the armature node exactly when the model does, so Generic curve paths match.
- Unity refreshes on request while in the background (ArtSource/.bridge/refresh.request), for tools and tests.
