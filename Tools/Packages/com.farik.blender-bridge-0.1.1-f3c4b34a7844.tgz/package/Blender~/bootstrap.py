"""Loaded by Unity with:  Blender [file.blend] --python bootstrap.py -- --ub-manifest <session.json>

Registers the add-on straight from the Unity package (nothing to install) and starts the session.
"""

import os
import sys

import bpy


def _arg(name):
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if name in argv:
        i = argv.index(name)
        return argv[i + 1] if i + 1 < len(argv) else None
    return None


# The add-on runs from the Unity package; keep __pycache__ folders out of the project.
sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import unity_bridge  # noqa: E402

if hasattr(bpy.types.Scene, "ub_state") and not unity_bridge._registered:
    # An installed copy of the add-on is already active; use it rather than registering twice.
    print("[UnityBridge] Using the installed add-on; package version is", unity_bridge.VERSION)
else:
    unity_bridge.register()

_manifest = _arg("--ub-manifest")
if _manifest:
    # The model is the start file here, so skip the splash screen. Blender shows it after the
    # startup scripts have run; the preference is put back right away and is not saved.
    _view = bpy.context.preferences.view
    if _view.show_splash and not bpy.app.background:
        _was_dirty = bpy.context.preferences.is_dirty
        _view.show_splash = False

        def _restore_splash():
            _view.show_splash = True
            bpy.context.preferences.is_dirty = _was_dirty
            return None

        bpy.app.timers.register(_restore_splash, first_interval=0.5)
    unity_bridge.session.start(_manifest)
