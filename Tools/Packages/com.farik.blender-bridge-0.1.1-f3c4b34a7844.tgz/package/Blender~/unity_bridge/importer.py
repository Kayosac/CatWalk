"""Builds the working scene from Unity's files: model, clip FBX files and sampled .anim clips."""

import json
import os
from contextlib import contextmanager

import bpy
from mathutils import Matrix

from . import actions, baking, fbx_nodes, fbx_profile, fingerprint, util

IMPORTER_LEGACY = "LEGACY"
IMPORTER_CPP = "CPP"


# --------------------------------------------------------------------------- operators


def _window_override():
    wm = bpy.context.window_manager
    if wm is not None and wm.windows:
        win = wm.windows[0]
        return {"window": win, "screen": win.screen}
    return {}


def call_op(op, **kwargs):
    """Calls an operator with only the arguments it knows (they differ between versions)."""
    known = set(op.get_rna_type().properties.keys())
    args = {k: v for k, v in kwargs.items() if k in known}
    ov = _window_override()
    if ov:
        with bpy.context.temp_override(**ov):
            return op(**args)
    return op(**args)


def _legacy_available():
    try:
        bpy.ops.import_scene.fbx.get_rna_type()
        return True
    except (AttributeError, KeyError, RuntimeError):
        return False


def import_fbx(path, use_anim, importer=None):
    """Imports into the active collection. Returns (objects, actions) created by the import."""
    importer = importer or (IMPORTER_LEGACY if _legacy_available() else IMPORTER_CPP)
    before_obj = set(bpy.data.objects)
    before_act = set(bpy.data.actions)
    if importer == IMPORTER_LEGACY:
        res = call_op(
            bpy.ops.import_scene.fbx, filepath=path, use_manual_orientation=False, global_scale=1.0,
            bake_space_transform=False, use_custom_normals=True, colors_type="SRGB",
            use_image_search=False, use_alpha_decals=False, use_anim=use_anim, anim_offset=0.0,
            use_subsurf=False, use_custom_props=True, use_custom_props_enum_as_string=True,
            ignore_leaf_bones=False, force_connect_children=False, automatic_bone_orientation=False,
            primary_bone_axis="Y", secondary_bone_axis="X", use_prepost_rot=True)
    else:
        res = call_op(
            bpy.ops.wm.fbx_import, filepath=path, global_scale=1.0, use_custom_normals=True,
            import_colors="SRGB", use_custom_props=True, use_custom_props_enum_as_string=True,
            ignore_leaf_bones=False, use_anim=use_anim, anim_offset=0.0, validate_meshes=False)
    if "FINISHED" not in res:
        raise RuntimeError("FBX import failed: %s" % path)
    new_obj = [o for o in bpy.data.objects if o not in before_obj]
    new_act = [a for a in bpy.data.actions if a not in before_act]
    return new_obj, new_act


# --------------------------------------------------------------------------- scene


def clear_scene():
    """Empties the startup scene without reloading preferences or add-ons."""
    scene = bpy.context.scene
    st = getattr(scene, "ub_state", None)
    if st is not None:
        # The scene survives, so does its state: drop the old file/clip lists (they hold actions).
        st.issues.clear()
        st.clips.clear()
        st.files.clear()
        st.clip_index = -1
    for ob in list(bpy.data.objects):
        bpy.data.objects.remove(ob, do_unlink=True)
    for col in list(bpy.data.collections):
        bpy.data.collections.remove(col)
    for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.cameras, bpy.data.lights,
                 bpy.data.armatures, bpy.data.actions, bpy.data.images, bpy.data.curves):
        for block in list(coll):
            if block.users - int(block.use_fake_user) <= 0:
                coll.remove(block)
    try:
        bpy.data.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
    except TypeError:
        bpy.data.orphans_purge()
    for other in list(bpy.data.scenes):
        if other != scene:
            bpy.data.scenes.remove(other)
    return scene


def setup_scene(scene, profile):
    """Scenes are always in true metres; the exporter reproduces the file's own units."""
    us = scene.unit_settings
    us.system = "METRIC"
    us.scale_length = 1.0
    us.length_unit = "METERS"
    fps = float(profile.get("fps") or 30.0)
    r = max(1, int(round(fps)))
    scene.render.fps = r
    scene.render.fps_base = r / fps if fps > 0 else 1.0


def find_layer_collection(layer_col, collection):
    if layer_col.collection == collection:
        return layer_col
    for child in layer_col.children:
        found = find_layer_collection(child, collection)
        if found:
            return found
    return None


class active_collection:
    """Context manager: imports and exports work on the view layer's active collection."""

    def __init__(self, collection):
        self.collection = collection
        self.prev = None

    def __enter__(self):
        vl = bpy.context.view_layer
        self.prev = vl.active_layer_collection
        lc = find_layer_collection(vl.layer_collection, self.collection)
        if lc is None:
            raise RuntimeError("Collection %s is not in the view layer" % self.collection.name)
        if lc.exclude:
            lc.exclude = False
        vl.active_layer_collection = lc
        return lc

    def __exit__(self, *exc):
        try:
            bpy.context.view_layer.active_layer_collection = self.prev
        except (ReferenceError, TypeError):
            pass


def model_collection(scene):
    st = scene.ub_state
    return bpy.data.collections.get(st.collection_name) if st.collection_name else None


def armatures(collection):
    return sorted((o for o in collection.all_objects if o.type == "ARMATURE"), key=lambda o: o.name)


def main_armature(collection):
    arms = armatures(collection)
    if not arms:
        return None
    return max(arms, key=lambda o: len(o.data.bones))


# --------------------------------------------------------------------------- baseline


_OBJECT_CHANNELS = ("rotation_mode", "location", "rotation_quaternion", "rotation_euler", "rotation_axis_angle", "scale")
_TRANSFORM_PATHS = {"location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle", "scale",
                    "delta_location", "delta_rotation_euler", "delta_rotation_quaternion", "delta_scale"}


def object_channels(o):
    return {k: (getattr(o, k) if k == "rotation_mode" else list(getattr(o, k))) for k in _OBJECT_CHANNELS}


def set_object_channels(o, values):
    for k in _OBJECT_CHANNELS:  # rotation_mode first
        if k in values:
            setattr(o, k, values[k])


def _slot_targets(slot, o):
    if slot is None:
        return True  # legacy action without slots
    if getattr(slot, "target_id_type", "OBJECT") not in ("OBJECT", "UNSPECIFIED"):
        return False
    try:
        if o in slot.users():
            return True
    except (AttributeError, TypeError):
        pass
    return getattr(slot, "name_display", None) == o.name


def transform_animated(o):
    """True when any action keys this object's own transform: the assigned one, an NLA strip, or
    another clip of the model (its last frame stays on the object after switching to a clip that
    does not key the object)."""
    for act in bpy.data.actions:
        # Clips of the model belong to its armature even when their slot has another name.
        picked = actions.find_slot(act, o) if o.type == "ARMATURE" else None
        for slot, bag in actions.iter_channelbags(act):
            if not any(fc.data_path in _TRANSFORM_PATHS for fc in bag.fcurves):
                continue
            if _slot_targets(slot, o) or (picked is not None and slot == picked):
                return True
    return False


@contextmanager
def static_transforms(collection, baseline, objects=None):
    """Objects whose transform is animated sit at the source file's default transform meanwhile.

    The current value of such an object is a frame of some clip, not an edit: fingerprints and the
    exported default must not depend on which frame the scene happens to be on."""
    saved = []
    defaults = (baseline or {}).get("transforms") or {}
    for o in (objects if objects is not None else [o for o in collection.all_objects if transform_animated(o)]):
        vals = defaults.get(o.name)
        if vals is None:
            continue
        saved.append((o, object_channels(o)))
        set_object_channels(o, vals)
    try:
        yield
    finally:
        for o, vals in reversed(saved):
            try:
                set_object_channels(o, vals)
            except ReferenceError:
                pass


def capture_baseline(collection):
    objects = {o.name: o.type for o in collection.all_objects}
    bones = {a.name: [b.name for b in a.data.bones] for a in armatures(collection)}
    materials = sorted({s.material.name for o in collection.all_objects for s in getattr(o, "material_slots", [])
                        if s.material})
    pose = {}
    for a in armatures(collection):
        pose[a.name] = {pb.name: [v for row in pb.matrix_basis for v in row] for pb in a.pose.bones}
    transforms = {o.name: object_channels(o) for o in collection.all_objects}
    return {"objects": objects, "bones": bones, "materials": materials, "pose": pose, "transforms": transforms}


def _pose_channels(pb):
    """Raw channels restore exactly; matrix_basis would re-decompose with float noise."""
    return {k: (getattr(pb, k) if k == "rotation_mode" else tuple(getattr(pb, k)))
            for k in ("rotation_mode", "location", "rotation_quaternion", "rotation_euler", "rotation_axis_angle", "scale")}


def restore_static_pose(collection, baseline):
    """Puts every armature back into the default pose read from the FBX (node defaults)."""
    saved = {}
    for a in armatures(collection):
        bpose = baseline.get("pose", {}).get(a.name)
        if not bpose:
            continue
        saved[a.name] = {pb.name: _pose_channels(pb) for pb in a.pose.bones}
        for pb in a.pose.bones:
            vals = bpose.get(pb.name)
            pb.matrix_basis = Matrix((vals[0:4], vals[4:8], vals[8:12], vals[12:16])) if vals else Matrix.Identity(4)
    return saved


def restore_pose_values(collection, saved):
    for a in armatures(collection):
        values = saved.get(a.name)
        if not values:
            continue
        for pb in a.pose.bones:
            ch = values.get(pb.name)
            if ch is not None:
                for k, v in ch.items():
                    setattr(pb, k, v)


# --------------------------------------------------------------------------- viewport textures


def _image_exists(img):
    if img.packed_file is not None:
        return True
    try:
        return os.path.isfile(bpy.path.abspath(img.filepath))
    except (ValueError, OSError):
        return False


def apply_preview_textures(materials):
    """materials: [{'name': 'Body', 'texture': '/abs/albedo.png'}] sent by Unity."""
    for info in materials or []:
        mat = bpy.data.materials.get(info.get("name", ""))
        tex = info.get("texture")
        if mat is None or not tex or not os.path.isfile(tex):
            continue
        try:
            mat.use_nodes = True
        except AttributeError:
            pass
        nt = mat.node_tree
        if nt is None:
            continue
        bsdf = next((n for n in nt.nodes if n.type == "BSDF_PRINCIPLED"), None)
        if bsdf is None:
            continue
        img = bpy.data.images.load(tex, check_existing=True)
        if bsdf.inputs["Base Color"].is_linked:
            # The FBX may point at a texture that is not where it says (shows pink); use Unity's instead.
            src = bsdf.inputs["Base Color"].links[0].from_node
            if src.type == "TEX_IMAGE" and (src.image is None or not _image_exists(src.image)):
                src.image = img
                src.label = "Unity preview"
                mat["ub_preview"] = True
            continue
        node = nt.nodes.new("ShaderNodeTexImage")
        node.image = img
        node.location = (bsdf.location.x - 320, bsdf.location.y)
        node.label = "Unity preview"
        nt.links.new(node.outputs["Color"], bsdf.inputs["Base Color"])
        mat["ub_preview"] = True


# --------------------------------------------------------------------------- takes


def _owner_and_take(action_name, take_names=()):
    """Blender's importer names actions 'Object|Take' or 'Object|Take|Layer' (when the layer has
    its own name, as in 3ds Max files). Known take names from the file decide where the take is."""
    for t in sorted(take_names, key=len, reverse=True):
        marker = "|" + t
        i = action_name.find(marker)
        if i > 0:
            rest = action_name[i + len(marker):]
            if rest == "" or rest.startswith("|"):
                return action_name[:i], t
    if "|" in action_name:
        owner, take = action_name.split("|", 1)
        return owner, take
    return "", action_name


def transfer_takes(temp_objects, new_actions, target_collection, profile_takes):
    """Moves actions created by an animation import onto the model's own objects.

    Returns [{'take', 'action', 'key_action', 'key_target'}] in the file's take order.
    """
    targets = {}
    key_targets = {}
    ours = {o.name: o for o in target_collection.all_objects}
    for tmp in temp_objects:
        base, _ = util.strip_blender_suffix(tmp.name)
        dst = ours.get(base)
        if dst is None or dst.type != tmp.type:
            continue
        targets[tmp.name] = dst
        if tmp.type == "MESH" and tmp.data.shape_keys is not None:
            key_targets[tmp.data.shape_keys.name] = dst
            key_targets[tmp.name] = dst

    takes = {}
    order = [t["name"] for t in profile_takes]
    single_arm = [o for o in target_collection.all_objects if o.type == "ARMATURE"]
    main = main_armature(target_collection)
    for act in new_actions:
        owner, take = _owner_and_take(act.name, [t["name"] for t in profile_takes])
        entry = takes.setdefault(take, {"take": take, "action": None, "key_action": None, "key_target": "",
                                        "dropped": []})
        dst = targets.get(owner)
        if dst is None and owner in key_targets:
            entry["key_action"] = act
            entry["key_target"] = key_targets[owner].name
            continue
        if dst is None and len(single_arm) == 1:
            dst = single_arm[0]
        if dst is not None and dst == main and entry["action"] is None:
            entry["action"] = act
        elif actions.is_animated(act):
            # Only the main skeleton and shape keys go back into the file; say what would be lost.
            entry["dropped"].append(dst.name if dst is not None else owner)
            util.log("Take", take, "also animates", entry["dropped"][-1], "which the export cannot write")
    result = []
    for name in order + [t for t in takes if t not in order]:
        e = takes.get(name)
        if e and (e["action"] or e["key_action"] or e["dropped"]):
            if e["action"] is not None:
                e["action"].name = name
                e["action"].use_fake_user = True
            if e["key_action"] is not None:
                e["key_action"].name = name + " (shape keys)"
                e["key_action"].use_fake_user = True
            result.append(e)
    return result


def remove_imported(temp_objects, keep_actions, new_actions=()):
    """Deletes temporary import results, keeping the listed actions."""
    data_blocks = set()
    for o in temp_objects:
        if o.data is not None:
            data_blocks.add(o.data)
            if getattr(o.data, "shape_keys", None) is not None:
                data_blocks.add(o.data.shape_keys)
        for slot in getattr(o, "material_slots", []):
            if slot.material is not None:
                data_blocks.add(slot.material)
    for o in temp_objects:
        bpy.data.objects.remove(o, do_unlink=True)
    removers = (
        (bpy.types.Mesh, bpy.data.meshes),
        (bpy.types.Armature, bpy.data.armatures),
        (bpy.types.Material, bpy.data.materials),
        (bpy.types.Curve, bpy.data.curves),
    )
    for block in sorted(data_blocks, key=lambda b: isinstance(b, bpy.types.Material)):
        try:
            if block.users != 0:
                continue
            for cls, coll in removers:
                if isinstance(block, cls):
                    coll.remove(block)
                    break
        except ReferenceError:
            pass
    for a in list(new_actions):
        # Imported actions carry a fake user, so the users == 0 sweep below misses them.
        try:
            if a not in keep_actions:
                bpy.data.actions.remove(a)
        except ReferenceError:
            pass
    for a in list(bpy.data.actions):
        if a.users == 0 and a not in keep_actions:
            bpy.data.actions.remove(a)


def _skeletons_match(arm_a, arm_b, tol=1e-4):
    if set(arm_a.data.bones.keys()) != set(arm_b.data.bones.keys()):
        return False
    sa = baking._uniform_scale(arm_a.matrix_world)
    sb = baking._uniform_scale(arm_b.matrix_world)
    if abs(sa - sb) > tol * max(sa, sb):
        return False
    wa, wb = arm_a.matrix_world, arm_b.matrix_world
    for b in arm_a.data.bones:
        ma = wa @ b.matrix_local
        mb = wb @ arm_b.data.bones[b.name].matrix_local
        for i in range(4):
            for j in range(4):
                if abs(ma[i][j] - mb[i][j]) > tol * (1.0 if j < 3 else max(1.0, sa)):
                    return False
    return True


def file_default_pose(path, target_arm, scene, temp_parent):
    """The file's own default (static) pose, as matrix_basis per bone of target_arm.

    A clip file's default pose is what Unity builds that file's avatar from, so it is written back
    as it was rather than replaced by the model's pose.
    """
    tmp_col = bpy.data.collections.new("UB_TMP_POSE")
    temp_parent.children.link(tmp_col)
    try:
        with active_collection(tmp_col):
            new_obj, new_act = import_fbx(path, use_anim=False)
        arms = [o for o in new_obj if o.type == "ARMATURE"]
        if not arms:
            return None
        src = max(arms, key=lambda o: len(o.data.bones))
        bpy.context.view_layer.update()
        world = [{pb.name: (src.matrix_world @ pb.matrix).copy() for pb in src.pose.bones}]
        poses = baking.world_to_target_pose(target_arm, src, world)[0]
        out = {target_arm.name: baking.pose_basis(target_arm, poses)}
        s_src, s_dst = baking._uniform_scale(src.matrix_world), baking._uniform_scale(target_arm.matrix_world)
        if abs(s_src - s_dst) <= 1e-4 * max(s_src, s_dst):
            # Same scale: the file's armature node can be reproduced too (bone curves are unaffected).
            out["__object__"] = {target_arm.name: [v for row in src.matrix_world for v in row]}
        remove_imported(new_obj, [], new_act)
        return out
    except Exception as e:  # noqa: BLE001
        util.log("Could not read the default pose of", path, "-", e)
        return None
    finally:
        bpy.data.collections.remove(tmp_col)


def import_takes_from(path, target_arm, scene, temp_parent):
    """Imports an FBX with animation and returns its takes as actions on target_arm."""
    tmp_col = bpy.data.collections.new("UB_TMP_IMPORT")
    temp_parent.children.link(tmp_col)
    try:
        with active_collection(tmp_col):
            new_obj, new_act = import_fbx(path, use_anim=True)
        prof = fbx_profile.read(path)
        src_arms = [o for o in new_obj if o.type == "ARMATURE"]
        if not src_arms:
            raise RuntimeError("No armature in %s" % os.path.basename(path))
        src = max(src_arms, key=lambda o: len(o.data.bones))
        reuse = _skeletons_match(src, target_arm)
        results = []
        by_take = {}
        dropped = {}
        for act in new_act:
            owner, take = _owner_and_take(act.name, [t["name"] for t in prof["takes"]])
            base, _ = util.strip_blender_suffix(owner)
            if owner and base != util.strip_blender_suffix(src.name)[0] and owner != src.name:
                if actions.is_animated(act):
                    dropped.setdefault(take, []).append(owner)
                continue
            by_take[take] = act
        prof["dropped"] = dropped
        order = [t["name"] for t in prof["takes"]] or list(by_take)
        keep = []
        for take in order:
            act = by_take.get(take)
            if act is None:
                continue
            if reuse:
                act.name = take
                act.use_fake_user = True
                keep.append(act)
                results.append({"take": take, "action": act, "start": actions.frame_range(act)[0]})
                continue
            actions.assign(src, act)
            lo, hi = actions.frame_range(act)
            frames = list(range(int(round(lo)), int(round(hi)) + 1))
            world = baking.sample_armature_world(scene, src, frames)
            poses = baking.world_to_target_pose(target_arm, src, world)
            baked = bpy.data.actions.new(take)
            baked.use_fake_user = True
            baking.bake_pose_matrices(target_arm, baked, frames, poses)
            keep.append(baked)
            results.append({"take": take, "action": baked, "start": lo})
        remove_imported(new_obj, keep, new_act)
        return results, prof
    finally:
        bpy.data.collections.remove(tmp_col)


# --------------------------------------------------------------------------- fresh model


def fresh_model(scene, model_abs_path, model_name, materials=None):
    """Imports the model into an empty scene. Returns (collection, profile, takes)."""
    profile = fbx_profile.read(model_abs_path)
    setup_scene(scene, profile)
    col = bpy.data.collections.new(model_name)
    scene.collection.children.link(col)
    with active_collection(col):
        import_fbx(model_abs_path, use_anim=False)
    nodes = fbx_nodes.read(model_abs_path)
    fix_bone_parented(col, nodes, profile)
    takes = []
    if profile["takes"]:
        tmp = bpy.data.collections.new("UB_TMP_TAKES")
        scene.collection.children.link(tmp)
        try:
            with active_collection(tmp):
                tmp_obj, tmp_act = import_fbx(model_abs_path, use_anim=True)
            takes = transfer_takes(tmp_obj, tmp_act, col, profile["takes"])
            keep = [t["action"] for t in takes if t["action"]] + [t["key_action"] for t in takes if t["key_action"]]
            remove_imported(tmp_obj, keep, tmp_act)
        finally:
            bpy.data.collections.remove(tmp)
        starts = {t["name"]: t["start_frame"] for t in profile["takes"]}
        for t in takes:
            t["start"] = starts.get(t["take"], 0.0)
    apply_preview_textures(materials)
    profile["clusters"] = nodes["clusters"]
    profile["mirrored"] = sorted(n for n, i in nodes["nodes"].items() if i.get("mirrored") and i["type"] == "LimbNode")
    return col, profile, takes


def file_global_matrix(profile):
    """What Blender's importer applies to the file's world space (axes and units -> metres)."""
    from bpy_extras.io_utils import axis_conversion

    u = float(profile.get("unit_scale_factor") or 1.0)
    return (Matrix.Scale(u / 100.0, 4) @
            axis_conversion(from_forward=profile.get("axis_forward", "-Z"),
                            from_up=profile.get("axis_up", "Y")).to_4x4())


def _depth(ob):
    d = 0
    while ob.parent is not None:
        ob, d = ob.parent, d + 1
    return d


def fix_bone_parented(collection, nodes, profile):
    """Blender's importer misplaces objects that hang under bones (weapons, sockets, Null nodes
    turned into empties) and their children. Put each mesh or empty back where the file says it is.
    Skinned meshes and armatures are left alone: their placement is part of the bind."""
    if not nodes.get("nodes"):
        return 0
    G = file_global_matrix(profile)
    fixed = 0
    candidates = [o for o in collection.all_objects
                  if o.type in {"MESH", "EMPTY"} and o.name in nodes["nodes"]
                  and not any(m.type == "ARMATURE" for m in getattr(o, "modifiers", []))]
    for ob in sorted(candidates, key=_depth):
        bpy.context.view_layer.update()
        want = G @ Matrix(nodes["nodes"][ob.name]["world"].tolist())
        have = ob.matrix_world
        scale = max(1e-6, baking._uniform_scale(want))
        err = max(abs(want[i][j] - have[i][j]) / (scale if j < 3 else max(1.0, scale))
                  for i in range(3) for j in range(4))
        if err > 1e-4:
            ob.matrix_world = want
            fixed += 1
    if fixed:
        bpy.context.view_layer.update()
        util.log("Placed %d object(s) where the file has them" % fixed)
    return fixed


def ensure_helpers_collection(scene):
    col = bpy.data.collections.get("Helpers (not exported)")
    if col is None:
        col = bpy.data.collections.new("Helpers (not exported)")
        scene.collection.children.link(col)
    return col


# --------------------------------------------------------------------------- new clip


def new_clip_action(arm_obj, name, length=30):
    act = bpy.data.actions.new(name)
    act.use_fake_user = True
    actions.assign(arm_obj, act)
    act.use_frame_range = True
    act.frame_start = 0
    act.frame_end = length
    # One key at rest on frame 0 so the clip is never empty and every bone has a channel.
    slot = actions.slot_of(arm_obj)
    bag = actions.ensure_channelbag(act, slot)
    for pb in arm_obj.pose.bones:
        pb.rotation_mode = "QUATERNION"
        base = 'pose.bones["%s"]' % bpy.utils.escape_identifier(pb.name)
        for path, vals in ((".location", pb.location), (".rotation_quaternion", pb.rotation_quaternion),
                           (".scale", pb.scale)):
            for i, v in enumerate(vals):
                fc = actions.new_fcurve(bag, base + path, i, pb.name)
                actions.write_samples(fc, [0.0], [float(v)])
    return act


# --------------------------------------------------------------------------- Unity samples


def load_anim_samples(arm_obj, sample_path, clip_name):
    sample = util.read_json(sample_path)
    if not sample:
        raise RuntimeError("Unity samples are missing: %s" % sample_path)
    poses, resid = baking.unity_samples_to_pose(arm_obj, sample)
    # Unity sampled at the clip's own rate; place the samples on the scene's frame grid.
    scene = bpy.context.scene
    scene_fps = scene.render.fps / (scene.render.fps_base or 1.0)
    clip_fps = float(sample.get("fps") or scene_fps)
    step = scene_fps / clip_fps
    frames = [i * step for i in range(len(poses))]
    act = bpy.data.actions.new(clip_name)
    act.use_fake_user = True
    baking.bake_pose_matrices(arm_obj, act, frames, poses)
    if sample.get("stepped"):
        for fc in actions.iter_fcurves(act):
            for kp in fc.keyframe_points:
                kp.interpolation = "CONSTANT"
    act.use_frame_range = True
    act.frame_start = 0
    act.frame_end = max(0.0, frames[-1] if frames else 0.0)
    return act, resid


def baseline_json(collection):
    return json.dumps(capture_baseline(collection))


def model_fps(collection, baseline=None):
    """Model fingerprints with animated objects at their default transform (see static_transforms)."""
    with static_transforms(collection, baseline):
        return fingerprint.model_fingerprints(collection)
