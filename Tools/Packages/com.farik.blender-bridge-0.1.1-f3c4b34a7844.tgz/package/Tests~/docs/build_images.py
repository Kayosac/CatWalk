"""Builds the README images from raw captures into Documentation~/images.

  python3 build_images.py <captures dir> <Documentation~/images>

Captures come from Unity's automation file (capture …) and Tests~/blender/docshots.py:
01-03 (model mode), 04-06 (clip mode), unity_*.png. Needs Pillow and the Inter font.
"""
import os
import sys

from PIL import Image, ImageDraw, ImageFont

SRC = sys.argv[1]          # folder with the raw captures
OUT = sys.argv[2]          # Documentation~/images
os.makedirs(OUT, exist_ok=True)

FONT = "/usr/share/fonts/opentype/inter/Inter-SemiBold.otf"
FONT_B = "/usr/share/fonts/opentype/inter/Inter-Bold.otf"
ACCENT = (245, 140, 40)
BG = (30, 31, 34)


def font(size, bold=False):
    return ImageFont.truetype(FONT_B if bold else FONT, size)


def load(name):
    return Image.open(os.path.join(SRC, name)).convert("RGB")


def save(im, name, **kw):
    p = os.path.join(OUT, name)
    if name.endswith(".jpg"):
        im.save(p, quality=kw.get("quality", 86), optimize=True, progressive=True)
    else:
        im.save(p, optimize=True)
    print(name, im.size, os.path.getsize(p) // 1024, "KB")


def highlight(im, box, width=3, pad=4, radius=6):
    d = ImageDraw.Draw(im)
    x0, y0, x1, y1 = box
    d.rounded_rectangle((x0 - pad, y0 - pad, x1 + pad, y1 + pad), radius=radius, outline=ACCENT, width=width)
    return im


def badge(d, cx, cy, n, r=13):
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=ACCENT)
    f = font(int(r * 1.35), True)
    d.text((cx, cy + 1), str(n), font=f, fill=(20, 20, 20), anchor="mm")


def fit(im, w, h):
    s = min(w / im.width, h / im.height)
    return im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)


def framed(im, caption, size=(1200, 760), bar=64):
    canvas = Image.new("RGB", size, BG)
    d = ImageDraw.Draw(canvas)
    d.text((28, bar // 2), caption, font=font(28, True), fill=(240, 240, 240), anchor="lm")
    body = fit(im, size[0] - 40, size[1] - bar - 20)
    canvas.paste(body, ((size[0] - body.width) // 2, bar + (size[1] - bar - 20 - body.height) // 2 + 4))
    return canvas


# ---------------------------------------------------------------- Unity inspector
insp = load("unity_inspector.png")
btn = (303, 94, 445, 112)
head = insp.crop((0, 0, 460, 124))
save(highlight(head.copy(), btn), "unity_inspector.png")

# ---------------------------------------------------------------- Blender windows
b01, b02, b03 = load("01_blender_opened.png"), load("02_blender_edited.png"), load("03_blender_exported.png")
b04, b05 = load("04_blender_clips.png"), load("05_blender_new_clip.png")
W = 1600
win = b01.crop((330, 40, 1690, 1150))  # viewport and the Unity panel
save(win.resize((1224, 999), Image.LANCZOS), "blender_window.jpg")

# Before / after of the edit, Object Mode, same view.
house = (480, 250, 1330, 1210)
before, after = b01.crop(house), b03.crop(house)
gap = 16
ba = Image.new("RGB", (before.width * 2 + gap, before.height + 56), BG)
ba.paste(before, (0, 56))
ba.paste(after, (before.width + gap, 56))
d = ImageDraw.Draw(ba)
d.text((before.width // 2, 28), "до", font=font(30, True), fill=(220, 220, 220), anchor="mm")
d.text((before.width + gap + after.width // 2, 28), "после: крыша выше", font=font(30, True), fill=ACCENT, anchor="mm")
save(ba.resize((ba.width * 3 // 4, ba.height * 3 // 4), Image.LANCZOS), "blender_edit.jpg")

# Edit Mode with the panel saying what changed.
save(b02.crop((380, 60, 1690, 1150)).resize((1048, 872), Image.LANCZOS), "blender_edit_mode.jpg")

# Panels.
panel = (1322, 92, 1672, 722)
p04, p05 = b04.crop(panel), b05.crop(panel)
save(p04, "blender_clips.png")

# New clip: viewport + panel.
save(b05.crop((420, 90, 1690, 990)).resize((1016, 720), Image.LANCZOS), "blender_new_clip.jpg")

# Annotated panel.
m = 46
ann = Image.new("RGB", (p05.width + m, p05.height), BG)
ann.paste(p05, (m, 0))
d = ImageDraw.Draw(ann)
for n, y in ((1, 100), (2, 178), (3, 216), (4, 350), (5, 530)):
    badge(d, m // 2, y, n)
    d.line((m // 2 + 14, y, m + 6, y), fill=ACCENT, width=3)
save(ann, "blender_panel_annotated.png")

# ---------------------------------------------------------------- Unity windows
rep = load("unity_reports.png").crop((0, 0, 560, 140))
hist = load("unity_history.png").crop((0, 0, 560, 128))
repc = load("unity_reports_clip.png").crop((0, 0, 560, 140))
save(rep, "unity_reports.png")
save(hist, "unity_history.png")
save(repc, "unity_reports_clip.png")
sett = load("unity_settings.png").crop((300, 46, 1106, 400))
save(sett, "unity_settings.png")

# ---------------------------------------------------------------- hero GIF
frames = [
    (framed(highlight(insp.copy(), btn), "1  ·  Unity: Open in Blender"), 2200),
    (framed(b01, "2  ·  Blender открылся с моделью и панелью Unity"), 2200),
    (framed(b02, "3  ·  Правишь как обычно — панель видит, что изменилось"), 2400),
    (framed(b03, "4  ·  Export to Unity — записан только изменённый файл"), 2400),
    (framed(rep.resize((rep.width * 2, rep.height * 2), Image.LANCZOS), "5  ·  Unity импортировала и проверила: всё нетронутое на месте"), 3200),
]
pal = [f.convert("P", palette=Image.ADAPTIVE, colors=256, dither=Image.NONE) for f, _ in frames]
p = os.path.join(OUT, "hero.gif")
pal[0].save(p, save_all=True, append_images=pal[1:], duration=[t for _, t in frames], loop=0, optimize=True, disposal=1)
print("hero.gif", os.path.getsize(p) // 1024, "KB")
# Static first look for places that do not animate.
save(framed(b03, "Blender Bridge: Open in Blender → правка → Export to Unity").resize((1200, 760)), "hero.jpg")
