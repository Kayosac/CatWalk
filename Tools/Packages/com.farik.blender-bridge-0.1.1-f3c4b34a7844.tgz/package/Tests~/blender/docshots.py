"""Screenshots for the documentation. Runs in Blender with UI, after bootstrap.py:

  Blender [file.blend] --python bootstrap.py --python docshots.py -- --ub-manifest <session.json>
          --ub-docshots <out dir> --ub-docshots-mode model|clip

Waits for the session, stages a typical edit, takes window screenshots at each step, exports
and quits. Started by Unity's automation request ("docshots <asset> <out dir> <mode>") on a copy
of the asset, so the project's own files are never touched.
"""

import os
import sys
import traceback

import bpy
from mathutils import Quaternion

from unity_bridge import clips, importer, util


def _arg(name):
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    return argv[argv.index(name) + 1] if name in argv else None


OUT = _arg("--ub-docshots")
MODE = _arg("--ub-docshots-mode") or "model"


def _log(*a):
    print("[docshots]", *a, flush=True)


def _view3d():
    win = bpy.context.window_manager.windows[0]
    for area in win.screen.areas:
        if area.type == "VIEW_3D":
            region = next(r for r in area.regions if r.type == "WINDOW")
            return win, area, region
    raise RuntimeError("No 3D viewport")


def _override():
    win, area, region = _view3d()
    return bpy.context.temp_override(window=win, screen=win.screen, area=area, region=region)


def _shot(name):
    path = os.path.join(OUT, name + ".png")
    with _override():
        bpy.ops.wm.redraw_timer(type="DRAW_WIN_SWAP", iterations=2)
        bpy.ops.screen.screenshot(filepath=path, check_existing=False)
    _log("shot", path)


def _frame(objects):
    with _override():
        if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        for o in bpy.context.view_layer.objects:
            o.select_set(o in objects)
        if objects:
            bpy.context.view_layer.objects.active = objects[0]
        bpy.ops.view3d.view_selected()
    _, area, _ = _view3d()
    r3d = area.spaces.active.region_3d
    r3d.view_rotation = Quaternion((0.7158, 0.4389, 0.2906, 0.4588)).normalized()  # Blender's default 3/4 view
    r3d.view_perspective = "PERSP"
    with _override():
        bpy.ops.view3d.view_selected()
    r3d.view_distance *= 1.25
    _deselect()


def _deselect():
    for o in bpy.context.view_layer.objects:
        o.select_set(False)


def _status(text_from_check=True):
    if text_from_check:
        with _override():
            bpy.ops.unity_bridge.check()


# --------------------------------------------------------------------------- steps


def _model_steps(scene):
    col = importer.model_collection(scene)
    meshes = [o for o in col.all_objects if o.type == "MESH" and len(o.data.vertices)]
    _frame(meshes)
    yield "01_blender_opened"
    # A visible edit: pull the top part of the biggest mesh up a little in Edit Mode.
    mesh = max(meshes, key=lambda o: len(o.data.vertices))
    mw = mesh.matrix_world
    zs = [(mw @ v.co).z for v in mesh.data.vertices]
    top = max(zs) - (max(zs) - min(zs)) * 0.15
    for p in mesh.data.polygons:
        p.select = False
    for e in mesh.data.edges:
        e.select = False
    for v in mesh.data.vertices:
        v.select = (mw @ v.co).z >= top
    for o in bpy.context.view_layer.objects:
        o.select_set(o == mesh)
    bpy.context.view_layer.objects.active = mesh
    with _override():
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_mode(type="VERT")
        bpy.ops.transform.translate(value=(0, 0, (max(zs) - min(zs)) * 0.12), orient_type="GLOBAL")
        bpy.ops.object.mode_set(mode="OBJECT")
    _status()
    with _override():
        bpy.ops.object.mode_set(mode="EDIT")
    yield "02_blender_edited"
    with _override():
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.unity_bridge.export(mode="SMART")
    _deselect()
    yield "03_blender_exported"


def _clip_steps(scene):
    col = importer.model_collection(scene)
    arm = importer.main_armature(col)
    _frame([arm] + [o for o in col.all_objects if o.type == "MESH"])
    st = scene.ub_state
    # Show an existing clip so the list has a loaded entry.
    if len(st.clips):
        st.clip_index = 0
        with _override():
            bpy.ops.unity_bridge.load_clip(index=0)
        scene.frame_set(scene.frame_start + 8)
    yield "04_blender_clips"
    name, n = "Wag", 1
    while any(c.name == name for c in st.clips):
        n += 1
        name = "Wag%d" % n
    clip = clips.new_clip(scene, name, 24)
    bones = arm.pose.bones
    pick = [pb for pb in bones if "tail" in pb.name.lower()] or [bones[len(bones) // 2]]
    for pb in pick[:3]:
        pb.rotation_mode = "QUATERNION"
        for f, a in ((1, 0.0), (7, 0.5), (13, 0.0), (19, -0.5), (24, 0.0)):
            pb.rotation_quaternion = Quaternion((0, 0, 1), a)
            pb.keyframe_insert("rotation_quaternion", frame=f)
    _log("new clip", clip.name, [pb.name for pb in pick[:3]])
    st.clip_index = len(st.clips) - 1
    scene.frame_set(7)
    _status()
    yield "05_blender_new_clip"
    with _override():
        bpy.ops.unity_bridge.export(mode="SMART")
    yield "06_blender_clip_exported"


_PREFS = {}


def _setup_look():
    # Bigger UI and textured solid shading read better in the docs; preferences are put back on quit.
    view = bpy.context.preferences.view
    _PREFS["ui_scale"] = view.ui_scale
    _PREFS["dirty"] = bpy.context.preferences.is_dirty
    view.ui_scale = 1.35
    _, area, _ = _view3d()
    shading = area.spaces.active.shading
    shading.type = "SOLID"
    shading.light = "STUDIO"
    shading.color_type = "TEXTURE"
    area.spaces.active.overlay.show_floor = True
    area.spaces.active.show_gizmo_navigate = False


def _restore_look():
    if "ui_scale" in _PREFS:
        bpy.context.preferences.view.ui_scale = _PREFS["ui_scale"]
        bpy.context.preferences.is_dirty = _PREFS["dirty"]


def _run():
    scene = bpy.context.scene
    st = getattr(scene, "ub_state", None)
    if st is None or not st.collection_name:
        return 0.5  # session not ready yet
    try:
        os.makedirs(OUT, exist_ok=True)
        _setup_look()
        steps = _model_steps(scene) if MODE == "model" else _clip_steps(scene)
        _queue(steps)
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        _finish(False)
    return None


def _queue(steps):
    # One step per timer tick so the viewport redraws between edits and screenshots.
    def tick():
        try:
            name = next(steps)
        except StopIteration:
            _finish(True)
            return None
        except Exception:  # noqa: BLE001
            traceback.print_exc()
            _finish(False)
            return None
        bpy.app.timers.register(lambda: (_shot(name), None)[1], first_interval=0.8)
        return 1.6

    bpy.app.timers.register(tick, first_interval=1.0)


def _finish(ok):
    with open(os.path.join(OUT, "blender_%s.%s" % (MODE, "done" if ok else "failed")), "w") as f:
        f.write("ok" if ok else "failed")
    _log("finished", ok)

    def quit_():
        _restore_look()
        bpy.ops.wm.quit_blender()
        return None

    bpy.app.timers.register(quit_, first_interval=1.0)


if OUT:
    bpy.app.timers.register(_run, first_interval=2.0)
