<div align="center">

# Blender Bridge

**Unity ⇄ Blender в одну кнопку в каждую сторону**

Открыл модель из Unity в Blender → поправил → **Export to Unity**. Без диалогов экспорта, без настроек, без сломанных префабов.

![Unity 6000.0+](https://img.shields.io/badge/Unity-6000.0%2B-222?logo=unity)
![Blender 5.0+](https://img.shields.io/badge/Blender-5.0%2B%20·%205.2%20LTS-E87D0D?logo=blender&logoColor=white)
![macOS · Windows · Linux](https://img.shields.io/badge/macOS%20·%20Windows%20·%20Linux-555)
![UPM](https://img.shields.io/badge/UPM-git%20URL-4c8)

<img src="Documentation~/images/hero.gif" width="860" alt="Unity → Blender → Unity: правка дома и экспорт обратно">

</div>

---

## Зачем

| Без моста | С мостом |
| --- | --- |
| Найти исходник .blend (если он вообще есть) | Кнопка **Open in Blender** у любого FBX, клипа, .anim или объекта на сцене |
| Помнить настройки экспорта FBX: оси, масштаб, «Apply Transform», «Bake Animation»… | **Export to Unity** — настройки исходного файла повторяются сами |
| Экспорт затирает клипы, материалы, ссылки | Перезаписывается только то, что поменялось. GUID и `.meta` остаются, префабы и сцены не рвутся |
| Новый клип = вся модель ещё раз | Новый клип пишется в `Модель@Клип.fbx` — только кости |
| «Что-то сломалось после экспорта» | Unity сравнивает «до/после» и даёт откат в один клик |

---

## Быстрый старт · 2 минуты

### 1. Установить

**Window ▸ Package Manager ▸ `+` ▸ Add package from git URL…**

```
https://github.com/Kayosac/Blender-Unity-Integration.git
```

Аддон в Blender ставить не нужно — Unity запускает Blender с аддоном прямо из пакета. Blender ищется сам: стандартная установка, Steam, Microsoft Store, snap/flatpak. Не нашёлся — **Preferences ▸ Blender Bridge ▸ Browse**.

### 2. Открыть модель

Выдели FBX в Project и нажми **Open in Blender** в шапке инспектора.
То же есть в контекстном меню: **ПКМ ▸ Blender ▸ Open in Blender** — в окне Project и на объекте в Hierarchy.

<img src="Documentation~/images/unity_inspector.png" width="460" alt="Кнопка Open in Blender в инспекторе FBX">

### 3. Поправить и вернуть

Blender откроется с моделью и панелью **Unity** справа (клавиша `N`). Правь как обычно, потом **Export to Unity**.

<img src="Documentation~/images/blender_window.jpg" width="860" alt="Blender: модель и панель Unity">

Вернись в Unity — файл импортируется сам, итог появится в консоли и в **Window ▸ Blender Bridge ▸ Reports**.

<img src="Documentation~/images/unity_reports.png" width="560" alt="Отчёт об импорте в окне Blender Bridge">

Всё. Дальше — подробности для тех, кому интересно, что происходит внутри.

---

## Что умеет

<table>
<tr>
<td width="50%" valign="top">

### 🧱 Правка меша
Статика, персонажи, пропсы. Форма, UV, вершинные цвета, shape keys, custom normals, UV2, новые части, LOD и коллайдеры по именам.

Перезаписывается тот же FBX — со старым GUID, поэтому все ссылки на модель живы.

</td>
<td width="50%" valign="top">

<img src="Documentation~/images/blender_edit.jpg" alt="До и после: верхняя крыша дома поднята">

</td>
</tr>
<tr>
<td valign="top">

### 🎬 Новый клип
**Clips ▸ New Clip** → анимируешь → **Export to Unity**.

Результат — `Модель@Клип.fbx` в папке `Animations/` рядом с моделью: только кости, 30 fps. Loop и Motion (на месте / root motion) — в панели, Humanoid-аватар Unity скопирует с модели. Сама модель при этом не перезаписывается.

<img src="Documentation~/images/unity_reports_clip.png" width="420" alt="Отчёт Unity: New clip created">

</td>
<td valign="top">

<img src="Documentation~/images/blender_new_clip.jpg" alt="Новый клип Wag в панели Clips">

</td>
</tr>
<tr>
<td valign="top">

### ✏️ Правка готовых клипов
Свои `@`-FBX, Mixamo, ассет-стор, клипы внутри FBX модели и `.anim`.
Каждый пишется туда, откуда пришёл: `.anim` остаётся `.anim` (с тем же GUID, событиями и прочими кривыми), клип внутри модели — внутри модели.

</td>
<td valign="top">

<img src="Documentation~/images/blender_clips.png" width="300" alt="Список клипов модели в Blender">

</td>
</tr>
<tr>
<td valign="top">

### ⏪ История и откат
Перед каждой перезаписью файл и его `.meta` копируются в историю. После импорта Unity сравнивает «до/после»: GUID, file ID частей, позы костей, нетронутые клипы. Что-то не так — **Restore**.

</td>
<td valign="top">

<img src="Documentation~/images/unity_history.png" alt="История экспорта с кнопкой Restore">

</td>
</tr>
</table>

### Все сценарии

| Что делаешь | Откуда открыть | Куда запишется |
| --- | --- | --- |
| Правка статичного меша | FBX в Project, объект в Hierarchy, кнопка в инспекторе | тот же FBX |
| Правка меша или скелета персонажа | то же | тот же FBX |
| Новый клип | открытая модель ▸ **Clips ▸ New Clip** | `Модель@Клип.fbx` (только кости) |
| Правка `@`-FBX клипа (свой, Mixamo, ассет-стор) | ПКМ на `@`-FBX или на клипе внутри него | тот же `@`-FBX |
| Правка клипа, зашитого в модель | ПКМ на клипе внутри FBX модели | тот же FBX модели |
| Правка `.anim` | ПКМ на `.anim`, кнопка в инспекторе | тот же `.anim` |
| Новая модель с нуля | **Assets ▸ Blender ▸ Create Model…** | новый FBX в выбранной папке |
| Откатить экспорт | **Window ▸ Blender Bridge ▸ History** | файл и `.meta` из истории |

---

## Как это работает

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="Documentation~/images/diagram_flow_dark.png">
  <img src="Documentation~/images/diagram_flow_light.png" width="820" alt="Схема: Open in Blender → правки → Export to Unity → импорт и проверка в Unity">
</picture>

**Главное правило:** источник истины — FBX (или `.anim`) в `Assets`. Рабочий `.blend` — просто удобная копия, его можно потерять без последствий: следующее открытие снова импортирует FBX.

<details>
<summary><b>Что значит «только изменения»</b></summary>

<img src="Documentation~/images/blender_edit_mode.jpg" width="640" alt="Edit Mode: панель показывает Changed: mesh">

- Blender считает отпечаток каждой части сцены: меш, скелет, каждый клип. Экспорт пишет только файлы, чьи отпечатки поменялись. Поправил хвост у собаки — запишется только клип с хвостом, модель останется байт-в-байт.
- Перезапись атомарная (временный файл → замена), поэтому GUID и `.meta` не трогаются. Префабы, сцены, Addressables, сетевые префабы продолжают ссылаться на ту же модель.
- Настройки импорта в Unity не меняются. Исключение — клипы, которые создал сам мост (Loop, Motion, аватар).
- Оси, единицы (UnitScaleFactor 1 или 100 записываются точно), fps и порядок дублей повторяют исходный файл.

</details>

---

## Панель Unity в Blender

<img src="Documentation~/images/blender_panel_annotated.png" width="360" align="right" alt="Панель Unity с номерами">

1. **Модель и статус.** Лупа — проверить, что изменилось, ничего не записывая.
2. **Export to Unity** — пишет только изменившееся. Стрелка рядом — **Export only…**: модель, активный клип или всё загруженное принудительно.
3. **Pin this .blend** — закрепить рабочий файл в git, если в нём есть то, чего нет в FBX: модификаторы, контрол-риг, хай-поли.
4. **Clips** — клипы модели: зашитые в модель, свои `@`-FBX, `.anim`. Клип грузится по клику. **New Clip** — новый клип.
5. **Настройки клипа** — диапазон кадров, Loop, Motion (на месте / root motion) и **Simplify keys** — прорядить ключи после запекания.

Если перед экспортом что-то не так, под кнопкой появляется **список проблем**: красные строки блокируют экспорт (есть **Export anyway**), кнопка рядом выделяет нужный объект или кость.

<br clear="right"/>

---

## Где живут рабочие .blend

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="Documentation~/images/diagram_blend-files_dark.png">
  <img src="Documentation~/images/diagram_blend-files_light.png" width="820" alt="Где живут рабочие .blend: Cache, Pinned и FBX в Assets">
</picture>

- **Cache** — для быстрых правок «здесь и сейчас». Чистится сам, но файл с неэкспортированными правками не удаляется никогда.
- **Pinned** — для моделей с живыми модификаторами, контрол-ригом, исходными ключами анимации.
- FBX изменился снаружи (git pull, откат)? При следующем открытии будет свежий импорт; неэкспортированные правки можно сохранить копией.
- `ArtSource/.gitignore` и `.gitattributes` создаются сами при первом открытии.

---

## Соглашения об именах

| Объект в Blender | Что получится в Unity |
| --- | --- |
| `Name_LOD0`, `Name_LOD1`, … | LODGroup |
| `Name_COL` | MeshCollider без рендерера |
| `Name_COLC` | выпуклый MeshCollider |
| `Name_COL_1`, `Name_COL_2` | несколько коллайдеров |
| материал `Wood` | слот `Wood`: берётся `Wood.mat` из проекта (ближайший к модели), иначе копия шаблонного материала |
| экшен `Run` при **New Clip** | `Модель@Run.fbx` |
| отдельная арматура с констрейнтами | контрол-риг: в Unity уходит только исходный скелет с запечёнными ключами |

Суффикс коллайдеров, папка клипов, шаблонный материал и срок кэша — в **Project Settings ▸ Blender Bridge**.

<img src="Documentation~/images/unity_settings.png" width="700" alt="Project Settings ▸ Blender Bridge">

---

## Что проверяется

<table>
<tr><th>Перед экспортом (Blender)</th><th>После импорта (Unity)</th></tr>
<tr><td valign="top">

- ⛔ переименованные или удалённые кости
- ⛔ суффиксы `.001` в именах
- ⛔ целевой файл пропал
- ⛔ дубль анимирует посторонние объекты
- ⚠️ переименованные объекты и слоты материалов
- ⚠️ отрицательный масштаб, больше 4 весов на вершину
- ⚠️ пропуски в цепочке LOD
- ⚠️ shape keys вместе с модификаторами
- ⚠️ файл из ассет-стора (перезапишется на месте)

</td><td valign="top">

- GUID файла
- file ID всех частей модели (меши, кости, клипы)
- позиция каждой кости в покое
- нетронутые клипы совпадают с прежними
- настройки импорта не изменились

Любое расхождение — ошибка в отчёте и кнопка отката.

</td></tr>
</table>

---

## Ограничения

- Меши вне FBX (`.asset`, ProBuilder) — пока нет.
- Дубль, который анимирует несколько скелетов сразу (например, 3ds Max Biped + второй скелет в одном файле), записать нельзя: экспорт остановится с понятной ошибкой, файл не пострадает.
- Зеркальные концевые кости с отрицательным масштабом (Nub-кости 3ds Max) сохраняют положение, но пишутся без зеркала — будет предупреждение.
- Анимация shape keys сохраняется для файлов с одним дублем.
- Humanoid-клипы `.anim` правятся через мышцы аватара: кости вне маппинга не правятся.
- Проверено на macOS (Blender 5.2.3 LTS, Unity 6). Поиск Blender на Windows и Linux написан, но в бою ещё не гонялся.
- События анимации и отчёт прямо в Blender — в следующих версиях.

---

## Неполадки

<details>
<summary><b>Blender не найден</b></summary>

**Preferences ▸ Blender Bridge ▸ Browse** (на macOS можно выбрать `Blender.app`) или **Detect**.
</details>

<details>
<summary><b>Экспорт прошёл, а в Unity ничего не поменялось</b></summary>

Переключись в Unity — импорт стартует сразу. Если файл так и не обновился — **Window ▸ Blender Bridge ▸ Cache ▸ Process pending exports now**, а причину смотри в **Reports** и в консоли.
</details>

<details>
<summary><b>«Already open in Blender»</b></summary>

Модель уже открыта в другом окне Blender. Второе окно перезаписало бы работу первого — переключись в него.
</details>

<details>
<summary><b>После импорта ошибка сравнения</b></summary>

**Window ▸ Blender Bridge ▸ History ▸ Restore** вернёт файл и `.meta` в состояние до экспорта. Причина будет в отчёте (**Reports**).
</details>

<details>
<summary><b>Export to Unity неактивна или заблокирована</b></summary>

Смотри список проблем в панели: красные строки блокируют экспорт. Кнопка выделения рядом покажет объект или кость. Если уверен — **Export anyway**.
</details>

---

## Проверено

- Цикл FBX → Blender → FBX без правок на 13 моделях реального проекта (статика, персонажи Mixamo и свои, собака с шестью зашитыми клипами, лучник из ассет-стора с колчаном на кости): нетронутое не меняется, повторные циклы не дают дрейфа, экспорт без правок ничего не пишет.
- Сквозной тест через Unity: правка меша, перезапись дублей, новые клипы Generic и Humanoid, правка `.anim` с ключами «через кадр» на 12 fps. Отклонение поворотов после цикла — меньше 0,0005°.

Запустить самому: **Assets ▸ Blender ▸ Run Self-Test** (фоновый Blender, ничего в проекте не меняет) и **Run End-to-End Test** (на копиях выделенных ассетов, копии удаляются после теста).

---

<details>
<summary><b>Для разработчиков: состав пакета и тесты из командной строки</b></summary>

| Папка | Что внутри |
| --- | --- |
| `Editor/` | Unity: меню, кнопка в инспекторе, запуск Blender, импорт результата, проверки, окно, настройки |
| `Blender~/` | Аддон Blender (`unity_bridge`) и `bootstrap.py`; Unity эту папку не импортирует |
| `Tests/Editor/` | Тесты Unity (Edit Mode) |
| `Tests~/blender/` | Стенд: циклы FBX → Blender → FBX, сквозной тест, скриншоты документации (`docshots.py`) |
| `Tests~/docs/` | Сборка картинок README из скриншотов |
| `Documentation~/diagrams/` | Исходники схем (Mermaid) и `render.sh`, который рисует их в светлом и тёмном варианте |
| `Documentation~/` | Полное руководство и картинки |

Цикл без Unity:

```
<Blender> -b --factory-startup \
  --python "<пакет>/Tests~/blender/phase0.py" -- \
  --ub-out /tmp/ub_phase0 --ub-fbx-dir "<папка с FBX>" --ub-cycles 3
```

`PASS` — первый цикл совпал с оригиналом в допусках, дальнейшие ничего не сдвигают, экспорт без правок не пишет файлов. `BLOCK` — инструмент остановил бы экспорт и объяснил почему.

</details>

Полное руководство: [Documentation~/index.md](Documentation~/index.md) · История версий: [CHANGELOG.md](CHANGELOG.md)
