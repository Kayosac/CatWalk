#!/bin/sh
# Renders the README diagrams (light and dark) into ../images. Needs mermaid-cli (mmdc).
cd "$(dirname "$0")"
for n in flow blend-files; do
  for mode in light dark; do
    mmdc -i "$n.mmd" -o "../images/diagram_${n}_${mode}.png" -c "$mode.json" -b transparent -s 2 -w 900
  done
done
