using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace Farik.BlenderBridge
{
    /// <summary>
    /// Lets external tools drive the editor while it is in the background (Unity reacts to the
    /// filesystem only when focused). One command per line in ArtSource/.bridge/automation.request:
    ///   select &lt;asset&gt;                    select and ping an asset (the inspector shows it)
    ///   open &lt;asset&gt;                      Open in Blender, as the menu does
    ///   window &lt;tab&gt; [asset]              Window ▸ Blender Bridge on Sessions, History, Reports or Cache (for one asset); "settings" opens Project Settings
    ///   copy &lt;asset&gt; &lt;folder&gt;             copy an asset into a scratch folder under Assets/BlenderBridge*
    ///   forget &lt;folder&gt;                   delete a scratch folder and every trace the bridge keeps of it
    ///   docshots &lt;asset&gt; &lt;dir&gt; &lt;mode&gt;     open in Blender and take documentation screenshots (Tests~/blender/docshots.py)
    ///   inspector [w h] | inspector close    open (or close) a floating inspector used by "capture inspector"
    ///   close &lt;window&gt;                   close every window of that kind (bridge, settings)
    ///   capture &lt;window&gt; &lt;png&gt;           save an editor window (inspector, project, hierarchy, console, bridge, scene, settings)
    /// Paths must not contain spaces. Commands run in order; a capture waits a few editor frames so the window has repainted.
    /// The result of each line is appended to ArtSource/.bridge/automation.log.
    /// </summary>
    internal static class Automation
    {
        public static string RequestFile => BridgePaths.Bridge + "/automation.request";
        public static string LogFile => BridgePaths.Bridge + "/automation.log";
        // Lines still to run. On disk, so a domain reload in the middle of a batch does not lose it.
        static string PendingFile => BridgePaths.Bridge + "/automation.pending";

        static EditorWindow _inspector;
        static int _wait;

        public static void Check()
        {
            if (File.Exists(RequestFile))
            {
                var lines = File.ReadAllLines(RequestFile).Select(l => l.Trim()).Where(l => l.Length > 0).ToList();
                File.Delete(RequestFile);
                File.AppendAllLines(PendingFile, lines);
            }
            if (File.Exists(PendingFile))
            {
                EditorApplication.update -= Tick;
                EditorApplication.update += Tick;
            }
        }

        static void Tick()
        {
            if (_wait > 0)
            {
                _wait--;
                return;
            }
            var pending = File.Exists(PendingFile) ? File.ReadAllLines(PendingFile).ToList() : new List<string>();
            if (pending.Count == 0)
            {
                if (File.Exists(PendingFile)) File.Delete(PendingFile);
                EditorApplication.update -= Tick;
                return;
            }
            var line = pending[0];
            pending.RemoveAt(0);
            if (pending.Count > 0) File.WriteAllLines(PendingFile, pending);
            else File.Delete(PendingFile);
            string result;
            try
            {
                result = Run(line);
            }
            catch (Exception e)
            {
                result = "ERROR " + e.Message;
            }
            File.AppendAllText(LogFile, DateTime.Now.ToString("HH:mm:ss") + "  " + line + "  ->  " + result + "\n");
        }

        static string Run(string line)
        {
            var parts = line.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var cmd = parts[0];
            string Arg(int i) => i < parts.Length ? parts[i] : "";
            switch (cmd)
            {
                case "select":
                {
                    var obj = AssetDatabase.LoadMainAssetAtPath(Arg(1));
                    if (obj == null) return "not found";
                    Selection.activeObject = obj;
                    EditorGUIUtility.PingObject(obj);
                    _wait = 10;
                    return "ok";
                }
                case "open":
                case "docshots":
                {
                    var obj = AssetDatabase.LoadMainAssetAtPath(Arg(1));
                    if (obj == null) return "not found";
                    Selection.activeObject = obj;
                    if (cmd == "docshots")
                    {
                        BlenderLocator.NextExtraScript = BridgePaths.PackageRoot + "/Tests~/blender/docshots.py";
                        BlenderLocator.NextExtraArgs = "--ub-docshots \"" + Arg(2) + "\" --ub-docshots-mode " +
                                                       (Arg(3).Length > 0 ? Arg(3) : "model");
                    }
                    var targets = TargetResolver.FromProjectSelection(out var unsupported);
                    if (targets == null || targets.Count != 1) return "expected one target: " + unsupported;
                    SessionLauncher.OpenTargets(targets, unsupported);
                    BlenderLocator.NextExtraScript = BlenderLocator.NextExtraArgs = null;
                    return "ok";
                }
                case "window":
                {
                    if (Arg(1) == "settings")
                    {
                        SettingsService.OpenProjectSettings(BridgeSettingsProvider.ProjectPath);
                        _wait = 20;
                        return "ok";
                    }
                    var tab = Enum.TryParse<BridgeWindow.Tab>(Arg(1), true, out var t) ? t : BridgeWindow.Tab.Sessions;
                    BridgeWindow.Open(tab, Arg(2).Length > 0 ? Arg(2) : null);
                    // Keep it on the main window's display, at a size that reads well in a screenshot.
                    var bw = Resources.FindObjectsOfTypeAll<BridgeWindow>().FirstOrDefault();
                    var main = EditorGUIUtility.GetMainWindowPosition();
                    if (bw != null) bw.position = new Rect(main.x + 160, main.y + 120, 560, 420);
                    _wait = 10;
                    return "ok";
                }
                case "copy":
                {
                    var src = Arg(1);
                    var folder = Arg(2).TrimEnd('/');
                    if (!IsScratch(folder)) return "folder must be under Assets/BlenderBridge*";
                    if (!AssetDatabase.IsValidFolder(folder))
                        AssetDatabase.CreateFolder(Path.GetDirectoryName(folder)?.Replace('\\', '/'), Path.GetFileName(folder));
                    var dst = folder + "/" + Path.GetFileName(src);
                    if (!AssetDatabase.CopyAsset(src, dst)) return "copy failed";
                    AssetDatabase.ImportAsset(dst, ImportAssetOptions.ForceSynchronousImport);
                    return "ok " + dst;
                }
                case "forget":
                {
                    var folder = Arg(1).TrimEnd('/');
                    if (!IsScratch(folder)) return "folder must be under Assets/BlenderBridge*";
                    var guids = AssetDatabase.IsValidFolder(folder)
                        ? AssetDatabase.FindAssets("", new[] { folder }).ToList()
                        : new List<string>();
                    if (AssetDatabase.IsValidFolder(folder)) AssetDatabase.DeleteAsset(folder);
                    Cleanup.ForgetFolder(folder, guids);
                    BridgeWindow.RepaintIfOpen();
                    return "ok";
                }
                case "inspector":
                {
                    // A floating inspector of our own, so a locked or busy one is left alone.
                    if (Arg(1) == "close")
                    {
                        if (_inspector != null) _inspector.Close();
                        _inspector = null;
                        return "ok";
                    }
                    var it = typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow");
                    _inspector = (EditorWindow)ScriptableObject.CreateInstance(it);
                    _inspector.Show();
                    int.TryParse(Arg(1), out var iw);
                    int.TryParse(Arg(2), out var ih);
                    _inspector.position = new Rect(120, 120, iw > 0 ? iw : 460, ih > 0 ? ih : 640);
                    _wait = 20;
                    return "ok";
                }
                case "close":
                {
                    // Only windows this tooling opens itself.
                    var type = Arg(1) == "bridge" ? typeof(BridgeWindow)
                        : Arg(1) == "settings" ? typeof(Editor).Assembly.GetType(WindowTypes["settings"]) : null;
                    if (type == null) return "only bridge or settings";
                    foreach (var ew in Resources.FindObjectsOfTypeAll(type).OfType<EditorWindow>().ToList()) ew.Close();
                    return "ok";
                }
                case "capture":
                    return Capture(Arg(1), Arg(2));
                default:
                    return "unknown command";
            }
        }

        static bool IsScratch(string folder) =>
            folder.StartsWith("Assets/BlenderBridge", StringComparison.Ordinal) && !folder.Contains("..");

        static readonly Dictionary<string, string> WindowTypes = new Dictionary<string, string>
        {
            { "inspector", "UnityEditor.InspectorWindow" },
            { "project", "UnityEditor.ProjectBrowser" },
            { "hierarchy", "UnityEditor.SceneHierarchyWindow" },
            { "console", "UnityEditor.ConsoleWindow" },
            { "scene", "UnityEditor.SceneView" },
            { "settings", "UnityEditor.ProjectSettingsWindow" },
        };

        /// <summary>Renders the window's dock area (tabs included) into a PNG, whatever covers it on screen.</summary>
        static string Capture(string which, string outPath)
        {
            var type = which == "bridge"
                ? typeof(BridgeWindow)
                : WindowTypes.TryGetValue(which, out var tn) ? typeof(Editor).Assembly.GetType(tn) : null;
            if (type == null) return "unknown window";
            // The visible tab of its dock area; of several inspectors, one that is not locked.
            var parentField = typeof(EditorWindow).GetField("m_Parent", BindingFlags.Instance | BindingFlags.NonPublic);
            object ParentOf(EditorWindow ew) => parentField?.GetValue(ew);
            bool Visible(EditorWindow ew)
            {
                var p = ParentOf(ew);
                var av = p?.GetType().GetProperty("actualView", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                return av == null || ReferenceEquals(av.GetValue(p), ew);
            }
            bool Locked(EditorWindow ew) =>
                ew.GetType().GetProperty("isLocked", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                    ?.GetValue(ew) is bool b && b;
            var w = which == "inspector" && _inspector != null ? _inspector : Resources.FindObjectsOfTypeAll(type).OfType<EditorWindow>()
                .Where(ew => ParentOf(ew) != null)
                .OrderByDescending(Visible).ThenBy(Locked).FirstOrDefault();
            if (w == null) return "window not open";
            var view = ParentOf(w);
            var grab = view.GetType().GetMethod("GrabPixels", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
                null, new[] { typeof(RenderTexture), typeof(Rect) }, null);
            var posProp = view.GetType().GetProperty("position", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (grab == null || posProp == null) return "GrabPixels is not available in this Unity version";
            var pos = (Rect)posProp.GetValue(view);
            var ppp = EditorGUIUtility.pixelsPerPoint;
            int pw = Mathf.RoundToInt(pos.width * ppp), ph = Mathf.RoundToInt(pos.height * ppp);
            var rt = new RenderTexture(pw, ph, 24, RenderTextureFormat.ARGB32, RenderTextureReadWrite.sRGB);
            var prev = RenderTexture.active;
            try
            {
                grab.Invoke(view, new object[] { rt, new Rect(0, 0, pw, ph) });
                RenderTexture.active = rt;
                var tex = new Texture2D(pw, ph, TextureFormat.RGBA32, false);
                tex.ReadPixels(new Rect(0, 0, pw, ph), 0, 0);
                // GrabPixels renders bottom-up.
                var px = tex.GetPixels32();
                var flipped = new Color32[px.Length];
                for (int y = 0; y < ph; y++) Array.Copy(px, y * pw, flipped, (ph - 1 - y) * pw, pw);
                tex.SetPixels32(flipped);
                tex.Apply();
                if (!Path.IsPathRooted(outPath)) outPath = BridgePaths.Abs(outPath);
                Directory.CreateDirectory(Path.GetDirectoryName(outPath) ?? ".");
                File.WriteAllBytes(outPath, tex.EncodeToPNG());
                UnityEngine.Object.DestroyImmediate(tex);
            }
            finally
            {
                RenderTexture.active = prev;
                rt.Release();
                UnityEngine.Object.DestroyImmediate(rt);
            }
            return "ok " + pw + "x" + ph;
        }
    }
}
